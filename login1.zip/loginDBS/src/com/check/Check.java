package com.check;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Check
 */
@WebServlet("/Check")
public class Check extends HttpServlet {
	public static String uname1;
public static String pwd1;
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		uname1=request.getParameter("uname");
 pwd1=request.getParameter("pwd");

	
}
    public static void connect() {
        Connection conn = null;
        try {
            // db parameters
            String url = "jdbc:sqlite:C:\\workspace\\loginDBS\\login.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);
		 
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT uname,pwd FROM user");
			       
            System.out.println("Connection to SQLite has been established.");
            System.out.println(uname1);
            while (rs.next()) {
            	 String uname = rs.getString("uname");

            	  String pwd = rs.getString("pwd");
            	  System.out.println(uname + "\n");
            	
            
            if(uname1.equals(uname) && pwd1.equals(pwd)) {
            	System.out.println("Login Done");
            	
            }
            else {
            	System.out.println("Login Failed");
            }

            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }


public static void main(String[] args) {
    connect();
   
}}
