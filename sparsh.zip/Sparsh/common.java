import java.util.*;
class common {
public static void main(String[] args) {
	ArrayList<Integer> common = new ArrayList<Integer>();
   int ar1[] = {2, 4, 8};
   int ar2[] = {2, 3, 4, 8, 10, 16};
   int ar3[] = {4, 8, 14, 40};
	int x = 0, y = 0, z = 0;
	while (x < ar1.length && y < ar2.length && z < ar3.length){
		if (ar1[x] == ar2[y] && ar2[y] == ar3[z]){
			common.add(ar1[x]);
			x++;
			y++;
			z++;
		}
		else if (ar1[x] < ar2[y])
			x++;
		else if (ar2[y] < ar3[z])
			y++;
		else
			z++;
	}
	System.out.println("Common elements are: ");
System.out.println(common);
}
}
