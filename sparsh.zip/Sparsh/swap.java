class swap{
public static void main(String[] args){
int a=23,b=32,temp;
temp=a;
a=b;
b=temp;
System.out.println(a);
System.out.println(b);




}







}