import java.util.Scanner;

class palin{
public static void main(String[] args)
{int m,a=0;
Scanner sc=new Scanner(System.in);
int i=sc.nextInt();
int temp=i;
while(i>0)
{
m=i%10;
a=a*10+m;
i=i/10;


}
if(a==temp)
{
System.out.println("palindrome");

}
else 
System.out.println("Not palindrome");
}}