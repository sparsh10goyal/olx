class array{
public static void main(String[] args)
{int arr[]={34,87,98,65,76,54,78,34,65,21,65,34,26,76,90,67,98,98,78,65};
int count=0;
for(int i=0;i<=19;i++)
{
if(arr[i]>=86)
{
count++;
}
}
System.out.println(count);
}
}