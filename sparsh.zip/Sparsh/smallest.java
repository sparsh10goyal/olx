import java.util.Scanner;
class smallest{
public static void main(String[] args)
{
Scanner sc =new Scanner(System.in);
System.out.println("Enter three numbers");
int a=sc.nextInt();
int b=sc.nextInt();
int c=sc.nextInt();
if(a<b){
if(a<c){
System.out.println("A is smallest");}
else
System.out.println("C is smallest");}
else{ if (b<c){System.out.println("B is the smallest");}
 else{System.out.println("C is the smallest");}}
}}