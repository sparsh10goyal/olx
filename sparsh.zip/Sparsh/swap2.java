class swap2{
public static void main(String[] args)
{int a=43,b=98;
a=a+b;

b=a-b;
a=a-b;
System.out.println(a);
System.out.println(b);
}
}