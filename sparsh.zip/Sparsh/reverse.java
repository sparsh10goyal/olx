import java.util.Scanner;
class reverse{
public static void main(String args[])

{
int i,temp;
System.out.println("Enter the string\n");
Scanner sc= new Scanner(System.in);
String str=sc.nextLine();
String reverse= "";
int j=str.length()-1;
for(i=j;i>=0;i--){
reverse=reverse+str.charAt(i);
}
System.out.println(reverse);

}

}
