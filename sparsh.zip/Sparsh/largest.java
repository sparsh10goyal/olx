class largest
{
    static void large(int arr[], int size)
    {
        int i, first, second, third;
   
        if (size < 3)
        {
            System.out.print(" Invalid Input ");
            return;
        }
       
        third = first = second = Integer.MIN_VALUE;
        for (i = 0; i < size ; i ++)
        {
            if (arr[i] > first)
            {
                third = second;
                second = first;
                first = arr[i];
            }
            else if (arr[i] > second)
            {
                third = second;
                second = arr[i];
            }
       
            else if (arr[i] > third)
                third = arr[i];
        }
       
        System.out.println("Three elements are " +
                       first + " " + second + " " + third);
    }
	 public static void main (String[] args)
{
        int arr[] = {12, 13, 1, 10, 34, 1};
        int n = arr.length;
        large(arr, n);
    }
}